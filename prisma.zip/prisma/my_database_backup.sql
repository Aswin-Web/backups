/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: agents
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AgentLevel`
--

DROP TABLE IF EXISTS `AgentLevel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentLevel` (
  `level_id` int(11) NOT NULL AUTO_INCREMENT,
  `super_admin_id` int(11) DEFAULT NULL,
  `level_name` varchar(191) NOT NULL,
  `level_descp` varchar(191) NOT NULL,
  `level_type` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`level_id`),
  KEY `AgentLevel_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `AgentLevel_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentLevel`
--

LOCK TABLES `AgentLevel` WRITE;
/*!40000 ALTER TABLE `AgentLevel` DISABLE KEYS */;
INSERT INTO `AgentLevel` VALUES (1,NULL,'level 1','none',NULL,'2024-12-16 15:36:56.557','2024-12-16 15:36:56.557');
/*!40000 ALTER TABLE `AgentLevel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentPrices`
--

DROP TABLE IF EXISTS `AgentPrices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentPrices` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_sub_prices_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `is_single_time_per_domain` tinyint(1) NOT NULL,
  `is_paid` tinyint(1) NOT NULL,
  `price` double NOT NULL,
  `current` tinyint(1) NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`price_id`),
  KEY `AgentPrices_agent_sub_prices_id_fkey` (`agent_sub_prices_id`),
  KEY `AgentPrices_super_admin_id_fkey` (`super_admin_id`),
  KEY `AgentPrices_currency_id_fkey` (`currency_id`),
  CONSTRAINT `AgentPrices_agent_sub_prices_id_fkey` FOREIGN KEY (`agent_sub_prices_id`) REFERENCES `AgentSubscriptionPrices` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentPrices_currency_id_fkey` FOREIGN KEY (`currency_id`) REFERENCES `Currency` (`currency_id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentPrices_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentPrices`
--

LOCK TABLES `AgentPrices` WRITE;
/*!40000 ALTER TABLE `AgentPrices` DISABLE KEYS */;
INSERT INTO `AgentPrices` VALUES (1,1,1,1,1,1500,1,NULL,'2024-12-16 15:40:29.985','2024-12-16 15:40:29.985'),(2,1,2,1,1,50,1,NULL,'2024-12-16 15:41:02.555','2024-12-16 15:41:02.555'),(3,2,1,1,0,0,1,NULL,'2024-12-16 15:41:44.308','2024-12-16 15:41:44.308');
/*!40000 ALTER TABLE `AgentPrices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentPurchase`
--

DROP TABLE IF EXISTS `AgentPurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentPurchase` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `start_date` datetime(3) NOT NULL,
  `end_date` datetime(3) NOT NULL,
  `order_item_id` int(11) DEFAULT NULL,
  `org_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`purchase_id`),
  KEY `AgentPurchase_order_item_id_fkey` (`order_item_id`),
  KEY `AgentPurchase_org_id_fkey` (`org_id`),
  KEY `AgentPurchase_order_id_fkey` (`order_id`),
  CONSTRAINT `AgentPurchase_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order` (`order_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AgentPurchase_order_item_id_fkey` FOREIGN KEY (`order_item_id`) REFERENCES `OrderItems` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AgentPurchase_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentPurchase`
--

LOCK TABLES `AgentPurchase` WRITE;
/*!40000 ALTER TABLE `AgentPurchase` DISABLE KEYS */;
INSERT INTO `AgentPurchase` VALUES (1,'2024-01-01 00:00:00.000','2025-01-01 00:00:00.000',NULL,NULL,NULL,'2024-12-16 17:51:09.895','2024-12-16 17:51:09.895');
/*!40000 ALTER TABLE `AgentPurchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentSubscription`
--

DROP TABLE IF EXISTS `AgentSubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentSubscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `sub_type_id` int(11) NOT NULL,
  `sub_feature_id` int(11) NOT NULL,
  `sub_config_id` int(11) NOT NULL,
  `sub_price_id` int(11) NOT NULL,
  `available_llm_id` int(11) NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `plan_name` varchar(191) NOT NULL,
  `disable` tinyint(1) NOT NULL,
  `access_user_limit` int(11) NOT NULL,
  `limit_level` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AgentSubscription_agent_id_fkey` (`agent_id`),
  KEY `AgentSubscription_level_id_fkey` (`level_id`),
  KEY `AgentSubscription_sub_type_id_fkey` (`sub_type_id`),
  KEY `AgentSubscription_sub_feature_id_fkey` (`sub_feature_id`),
  KEY `AgentSubscription_sub_config_id_fkey` (`sub_config_id`),
  KEY `AgentSubscription_available_llm_id_fkey` (`available_llm_id`),
  KEY `AgentSubscription_sub_price_id_fkey` (`sub_price_id`),
  KEY `AgentSubscription_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `AgentSubscription_agent_id_fkey` FOREIGN KEY (`agent_id`) REFERENCES `AgentTypes` (`agent_type_id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentSubscription_available_llm_id_fkey` FOREIGN KEY (`available_llm_id`) REFERENCES `AgentSubscriptionAvailableLLM` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentSubscription_level_id_fkey` FOREIGN KEY (`level_id`) REFERENCES `AgentLevel` (`level_id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentSubscription_sub_config_id_fkey` FOREIGN KEY (`sub_config_id`) REFERENCES `SubscriptionConfiguration` (`config_id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentSubscription_sub_feature_id_fkey` FOREIGN KEY (`sub_feature_id`) REFERENCES `SubscriptionFeatures` (`feature_id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentSubscription_sub_price_id_fkey` FOREIGN KEY (`sub_price_id`) REFERENCES `AgentSubscriptionPrices` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentSubscription_sub_type_id_fkey` FOREIGN KEY (`sub_type_id`) REFERENCES `SubscriptionType` (`sub_type_id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentSubscription_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentSubscription`
--

LOCK TABLES `AgentSubscription` WRITE;
/*!40000 ALTER TABLE `AgentSubscription` DISABLE KEYS */;
INSERT INTO `AgentSubscription` VALUES (1,1,1,1,1,1,2,1,NULL,'Starters',0,10000,5,'2024-12-16 15:56:10.808','2024-12-16 15:56:10.808'),(2,1,1,2,2,2,1,1,NULL,'Starters',0,10000,5,'2024-12-16 15:57:00.222','2024-12-16 15:57:00.222'),(3,2,1,1,1,1,2,1,NULL,'Starters',0,500,5,'2024-12-16 15:57:51.167','2024-12-16 15:57:51.167'),(4,2,1,2,3,2,1,1,NULL,'Starters',0,100,5,'2024-12-16 15:59:05.092','2024-12-16 15:59:05.092');
/*!40000 ALTER TABLE `AgentSubscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentSubscriptionAvailableLLM`
--

DROP TABLE IF EXISTS `AgentSubscriptionAvailableLLM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentSubscriptionAvailableLLM` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AgentSubscriptionAvailableLLM_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `AgentSubscriptionAvailableLLM_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentSubscriptionAvailableLLM`
--

LOCK TABLES `AgentSubscriptionAvailableLLM` WRITE;
/*!40000 ALTER TABLE `AgentSubscriptionAvailableLLM` DISABLE KEYS */;
INSERT INTO `AgentSubscriptionAvailableLLM` VALUES (1,NULL,'2024-12-16 15:53:16.344','2024-12-16 15:53:16.344');
/*!40000 ALTER TABLE `AgentSubscriptionAvailableLLM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentSubscriptionPrices`
--

DROP TABLE IF EXISTS `AgentSubscriptionPrices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentSubscriptionPrices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AgentSubscriptionPrices_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `AgentSubscriptionPrices_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentSubscriptionPrices`
--

LOCK TABLES `AgentSubscriptionPrices` WRITE;
/*!40000 ALTER TABLE `AgentSubscriptionPrices` DISABLE KEYS */;
INSERT INTO `AgentSubscriptionPrices` VALUES (1,NULL,'2024-12-16 15:38:17.599','2024-12-16 15:38:17.599'),(2,NULL,'2024-12-16 15:38:24.870','2024-12-16 15:38:24.870');
/*!40000 ALTER TABLE `AgentSubscriptionPrices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentTypes`
--

DROP TABLE IF EXISTS `AgentTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentTypes` (
  `agent_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `internal_name` varchar(191) NOT NULL,
  `external_name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `agent_icon` varchar(191) DEFAULT NULL,
  `python_base_url` varchar(191) DEFAULT NULL,
  `disable` tinyint(1) NOT NULL DEFAULT 1,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`agent_type_id`),
  KEY `AgentTypes_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `AgentTypes_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentTypes`
--

LOCK TABLES `AgentTypes` WRITE;
/*!40000 ALTER TABLE `AgentTypes` DISABLE KEYS */;
INSERT INTO `AgentTypes` VALUES (1,'helper_agent','helper_agent','none',NULL,NULL,0,NULL,'2024-12-16 15:37:36.337','2024-12-16 15:37:36.337'),(2,'Support_agent','support_agent',NULL,NULL,NULL,0,NULL,'2024-12-16 15:38:01.636','2024-12-16 15:38:01.636');
/*!40000 ALTER TABLE `AgentTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentVersionTrainingLogs`
--

DROP TABLE IF EXISTS `AgentVersionTrainingLogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentVersionTrainingLogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_id` int(11) NOT NULL,
  `training_status` enum('STARTED','PROCESSING','FAILED','FINISHED') NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AgentVersionTrainingLogs_version_id_fkey` (`version_id`),
  CONSTRAINT `AgentVersionTrainingLogs_version_id_fkey` FOREIGN KEY (`version_id`) REFERENCES `AgentVersions` (`version_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentVersionTrainingLogs`
--

LOCK TABLES `AgentVersionTrainingLogs` WRITE;
/*!40000 ALTER TABLE `AgentVersionTrainingLogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentVersionTrainingLogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AgentVersions`
--

DROP TABLE IF EXISTS `AgentVersions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AgentVersions` (
  `version_id` int(11) NOT NULL AUTO_INCREMENT,
  `version_name` varchar(191) NOT NULL,
  `agent_uuid` varchar(191) DEFAULT NULL,
  `raw_url` varchar(191) NOT NULL,
  `train_url` varchar(191) NOT NULL,
  `org_id` int(11) NOT NULL,
  `org_agent_id` int(11) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`version_id`),
  KEY `AgentVersions_org_id_fkey` (`org_id`),
  KEY `AgentVersions_org_agent_id_fkey` (`org_agent_id`),
  KEY `AgentVersions_org_user_id_fkey` (`org_user_id`),
  CONSTRAINT `AgentVersions_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentVersions_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `AgentVersions_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AgentVersions`
--

LOCK TABLES `AgentVersions` WRITE;
/*!40000 ALTER TABLE `AgentVersions` DISABLE KEYS */;
/*!40000 ALTER TABLE `AgentVersions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AvailableListAtLLMSubscription`
--

DROP TABLE IF EXISTS `AvailableListAtLLMSubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AvailableListAtLLMSubscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_subscription_available_llm_id` int(11) NOT NULL,
  `llm_providers_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `AvailableListAtLLMSubscription_agent_subscription_available_fkey` (`agent_subscription_available_llm_id`),
  KEY `AvailableListAtLLMSubscription_llm_providers_id_fkey` (`llm_providers_id`),
  KEY `AvailableListAtLLMSubscription_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `AvailableListAtLLMSubscription_agent_subscription_available_fkey` FOREIGN KEY (`agent_subscription_available_llm_id`) REFERENCES `AgentSubscriptionAvailableLLM` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `AvailableListAtLLMSubscription_llm_providers_id_fkey` FOREIGN KEY (`llm_providers_id`) REFERENCES `LLMProviders` (`llm_id`) ON UPDATE CASCADE,
  CONSTRAINT `AvailableListAtLLMSubscription_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AvailableListAtLLMSubscription`
--

LOCK TABLES `AvailableListAtLLMSubscription` WRITE;
/*!40000 ALTER TABLE `AvailableListAtLLMSubscription` DISABLE KEYS */;
INSERT INTO `AvailableListAtLLMSubscription` VALUES (1,1,1,1,NULL,'2024-12-16 15:53:43.513','2024-12-16 15:53:43.513'),(2,1,2,1,NULL,'2024-12-16 15:53:55.784','2024-12-16 15:53:55.784'),(3,1,3,1,NULL,'2024-12-16 15:54:06.844','2024-12-16 15:54:06.844');
/*!40000 ALTER TABLE `AvailableListAtLLMSubscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BillingInfo`
--

DROP TABLE IF EXISTS `BillingInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BillingInfo` (
  `billing_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `billing_name` int(11) NOT NULL,
  `address` varchar(191) NOT NULL,
  `org_id` int(11) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`billing_info_id`),
  KEY `BillingInfo_org_id_fkey` (`org_id`),
  KEY `BillingInfo_org_user_id_fkey` (`org_user_id`),
  CONSTRAINT `BillingInfo_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `BillingInfo_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BillingInfo`
--

LOCK TABLES `BillingInfo` WRITE;
/*!40000 ALTER TABLE `BillingInfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `BillingInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CartItems`
--

DROP TABLE IF EXISTS `CartItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CartItems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_subscription_id` int(11) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `CartItems_agent_subscription_id_fkey` (`agent_subscription_id`),
  KEY `CartItems_org_user_id_fkey` (`org_user_id`),
  CONSTRAINT `CartItems_agent_subscription_id_fkey` FOREIGN KEY (`agent_subscription_id`) REFERENCES `AgentSubscription` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `CartItems_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CartItems`
--

LOCK TABLES `CartItems` WRITE;
/*!40000 ALTER TABLE `CartItems` DISABLE KEYS */;
/*!40000 ALTER TABLE `CartItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatConversation`
--

DROP TABLE IF EXISTS `ChatConversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChatConversation` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_group_id` varchar(191) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `llm_type_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `answer` varchar(191) NOT NULL,
  `question` varchar(191) NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `ChatConversation_org_user_id_fkey` (`org_user_id`),
  KEY `ChatConversation_llm_type_id_fkey` (`llm_type_id`),
  KEY `ChatConversation_chat_group_id_fkey` (`chat_group_id`),
  CONSTRAINT `ChatConversation_chat_group_id_fkey` FOREIGN KEY (`chat_group_id`) REFERENCES `ChatGroups` (`chat_group_id`) ON UPDATE CASCADE,
  CONSTRAINT `ChatConversation_llm_type_id_fkey` FOREIGN KEY (`llm_type_id`) REFERENCES `OrganizationLLMEnabledInfo` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `ChatConversation_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatConversation`
--

LOCK TABLES `ChatConversation` WRITE;
/*!40000 ALTER TABLE `ChatConversation` DISABLE KEYS */;
INSERT INTO `ChatConversation` VALUES (2,'02f17d3d-df9d-4e7e-a400-83116b6e95c2',3,1,'2024-12-24 06:06:41.054','2024-12-24 06:06:41.054','Need to modify this ','Who is Ibacus tech'),(3,'d7d7c07e-73cc-4f3f-8401-dd9c2e9ec798',3,1,'2024-12-24 06:12:09.376','2024-12-24 06:12:09.376','Need to modify this ','Who is Ibacus tech'),(4,'eeeb0dcd-d8c7-4e44-92ae-fdff0a4ba6bc',3,1,'2024-12-24 06:12:32.927','2024-12-24 06:12:32.927','Need to modify this ','What do greenestep do?'),(5,'f4792bf8-080f-48f3-b453-3d57bad3b060',3,1,'2024-12-24 06:12:50.247','2024-12-24 06:12:50.247','Need to modify this ','Who is Akidev Corp?'),(6,'845a4ebf-7cbb-4387-90fa-ed61cdabbc8b',3,1,'2024-12-24 06:13:06.168','2024-12-24 06:13:06.168','Need to modify this ','Who is Sunil Kumar?'),(7,'d3e8be6a-1201-4790-956a-374ccbf36a1e',3,1,'2024-12-24 06:59:07.839','2024-12-24 06:59:07.839','Need to modify this ','Who is Sunil Kumar?'),(8,'79c18874-09ff-42b4-b1f9-e035f93793e4',3,1,'2024-12-24 06:59:10.041','2024-12-24 06:59:10.041','Need to modify this ','Who is Sunil Kumar?'),(9,'79c18874-09ff-42b4-b1f9-e035f93793e4',3,1,'2024-12-24 06:59:25.313','2024-12-24 06:59:25.313','Need to modify this ','Who is Sunil Kumar?'),(10,'79c18874-09ff-42b4-b1f9-e035f93793e4',3,1,'2024-12-24 06:59:26.632','2024-12-24 06:59:26.632','Need to modify this ','Who is Sunil Kumar?'),(11,'79c18874-09ff-42b4-b1f9-e035f93793e4',3,1,'2024-12-24 06:59:27.901','2024-12-24 06:59:27.901','Need to modify this ','Who is Sunil Kumar?'),(12,'79c18874-09ff-42b4-b1f9-e035f93793e4',3,1,'2024-12-24 06:59:29.605','2024-12-24 06:59:29.605','Need to modify this ','Who is Sunil Kumar?'),(13,'79c18874-09ff-42b4-b1f9-e035f93793e4',3,1,'2024-12-24 06:59:30.518','2024-12-24 06:59:30.518','Need to modify this ','Who is Sunil Kumar?'),(14,'79c18874-09ff-42b4-b1f9-e035f93793e4',3,1,'2024-12-24 06:59:31.492','2024-12-24 06:59:31.492','Need to modify this ','Who is Sunil Kumar?'),(15,'d7d7c07e-73cc-4f3f-8401-dd9c2e9ec798',3,1,'2024-12-24 07:43:42.455','2024-12-24 07:43:42.455','Need to modify this ','Who is Amul?'),(16,'d7d7c07e-73cc-4f3f-8401-dd9c2e9ec798',3,1,'2024-12-24 07:43:54.690','2024-12-24 07:43:54.690','Need to modify this ','Who is Ranu?'),(17,'d7d7c07e-73cc-4f3f-8401-dd9c2e9ec798',3,1,'2024-12-24 07:44:05.496','2024-12-24 07:44:05.496','Need to modify this ','What is their goal?');
/*!40000 ALTER TABLE `ChatConversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatGroups`
--

DROP TABLE IF EXISTS `ChatGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChatGroups` (
  `chat_group_id` varchar(191) NOT NULL,
  `chat_name` varchar(191) NOT NULL,
  `org_user_agents_id` int(11) DEFAULT NULL,
  `org_agent_id` int(11) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`chat_group_id`),
  KEY `ChatGroups_org_agent_id_fkey` (`org_agent_id`),
  KEY `ChatGroups_org_user_id_fkey` (`org_user_id`),
  KEY `ChatGroups_org_user_agents_id_fkey` (`org_user_agents_id`),
  CONSTRAINT `ChatGroups_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `ChatGroups_org_user_agents_id_fkey` FOREIGN KEY (`org_user_agents_id`) REFERENCES `OrganisationUserAgents` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ChatGroups_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatGroups`
--

LOCK TABLES `ChatGroups` WRITE;
/*!40000 ALTER TABLE `ChatGroups` DISABLE KEYS */;
INSERT INTO `ChatGroups` VALUES ('02f17d3d-df9d-4e7e-a400-83116b6e95c2','Who is Ibacus tech',NULL,6,3,'2024-12-24 06:06:41.016','2024-12-24 06:06:41.016'),('79c18874-09ff-42b4-b1f9-e035f93793e4','Who is Sunil Kumar?',NULL,6,3,'2024-12-24 06:59:10.035','2024-12-24 06:59:10.035'),('845a4ebf-7cbb-4387-90fa-ed61cdabbc8b','Who is Sunil Kumar?',NULL,6,3,'2024-12-24 06:13:06.162','2024-12-24 06:13:06.162'),('d3e8be6a-1201-4790-956a-374ccbf36a1e','Who is Sunil Kumar?',NULL,6,3,'2024-12-24 06:59:07.833','2024-12-24 06:59:07.833'),('d7d7c07e-73cc-4f3f-8401-dd9c2e9ec798','Who is Ibacus tech',NULL,6,3,'2024-12-24 06:12:09.368','2024-12-24 06:12:09.368'),('e76dbe2f-23bb-41c9-af9a-01597fe7a565','Who is Ibacus tech',NULL,6,3,'2024-12-24 06:03:35.325','2024-12-24 06:03:35.325'),('eeeb0dcd-d8c7-4e44-92ae-fdff0a4ba6bc','What do greenestep do?',NULL,6,3,'2024-12-24 06:12:32.921','2024-12-24 06:12:32.921'),('f4792bf8-080f-48f3-b453-3d57bad3b060','Who is Akidev Corp?',NULL,6,3,'2024-12-24 06:12:50.245','2024-12-24 06:12:50.245');
/*!40000 ALTER TABLE `ChatGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Currency`
--

DROP TABLE IF EXISTS `Currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Currency` (
  `currency_id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(191) NOT NULL,
  `currency_code` varchar(191) NOT NULL,
  `is_global` tinyint(1) NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`currency_id`),
  KEY `Currency_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `Currency_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Currency`
--

LOCK TABLES `Currency` WRITE;
/*!40000 ALTER TABLE `Currency` DISABLE KEYS */;
INSERT INTO `Currency` VALUES (1,'INR','inr',1,NULL,'2024-12-16 15:39:30.802','2024-12-16 15:39:30.802'),(2,'DOLLAR','usd',0,NULL,'2024-12-16 15:39:47.875','2024-12-16 15:39:47.875');
/*!40000 ALTER TABLE `Currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DurationInMonths`
--

DROP TABLE IF EXISTS `DurationInMonths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DurationInMonths` (
  `duration_in_month_id` int(11) NOT NULL AUTO_INCREMENT,
  `duration_name` varchar(191) NOT NULL,
  `no_of_months` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `discount_price` double NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`duration_in_month_id`),
  KEY `DurationInMonths_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `DurationInMonths_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DurationInMonths`
--

LOCK TABLES `DurationInMonths` WRITE;
/*!40000 ALTER TABLE `DurationInMonths` DISABLE KEYS */;
/*!40000 ALTER TABLE `DurationInMonths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExtPaymentInfo`
--

DROP TABLE IF EXISTS `ExtPaymentInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExtPaymentInfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_info` varchar(191) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `ExtPaymentInfo_org_user_id_fkey` (`org_user_id`),
  CONSTRAINT `ExtPaymentInfo_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExtPaymentInfo`
--

LOCK TABLES `ExtPaymentInfo` WRITE;
/*!40000 ALTER TABLE `ExtPaymentInfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExtPaymentInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LLMProviders`
--

DROP TABLE IF EXISTS `LLMProviders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LLMProviders` (
  `llm_id` int(11) NOT NULL AUTO_INCREMENT,
  `llm_internal_name` varchar(191) NOT NULL,
  `llm_external_name` varchar(191) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `llm_variable_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`llm_id`),
  KEY `LLMProviders_llm_variable_id_fkey` (`llm_variable_id`),
  CONSTRAINT `LLMProviders_llm_variable_id_fkey` FOREIGN KEY (`llm_variable_id`) REFERENCES `VariableInfo` (`variable_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LLMProviders`
--

LOCK TABLES `LLMProviders` WRITE;
/*!40000 ALTER TABLE `LLMProviders` DISABLE KEYS */;
INSERT INTO `LLMProviders` VALUES (1,'chat_gpt','Chat GPT','2024-12-16 15:52:04.783','2024-12-16 15:52:04.783',2),(2,'lama','Lama','2024-12-16 15:52:15.033','2024-12-16 15:52:15.033',3),(3,'gemini','Gemini','2024-12-16 15:52:26.917','2024-12-16 15:52:26.917',4);
/*!40000 ALTER TABLE `LLMProviders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Order`
--

DROP TABLE IF EXISTS `Order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `coupon_id` int(11) DEFAULT NULL,
  `order_status` varchar(191) NOT NULL,
  `coupon_discount` double NOT NULL,
  `final_price` double NOT NULL,
  `payment_status` varchar(191) NOT NULL,
  `ext_payment_info_id` int(11) NOT NULL,
  `billing_info_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `Order_org_user_id_fkey` (`org_user_id`),
  KEY `Order_ext_payment_info_id_fkey` (`ext_payment_info_id`),
  KEY `Order_billing_info_id_fkey` (`billing_info_id`),
  CONSTRAINT `Order_billing_info_id_fkey` FOREIGN KEY (`billing_info_id`) REFERENCES `BillingInfo` (`billing_info_id`) ON UPDATE CASCADE,
  CONSTRAINT `Order_ext_payment_info_id_fkey` FOREIGN KEY (`ext_payment_info_id`) REFERENCES `ExtPaymentInfo` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Order_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Order`
--

LOCK TABLES `Order` WRITE;
/*!40000 ALTER TABLE `Order` DISABLE KEYS */;
/*!40000 ALTER TABLE `Order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderItems`
--

DROP TABLE IF EXISTS `OrderItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderItems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `sub_type_id` int(11) NOT NULL,
  `sub_feature_id` int(11) NOT NULL,
  `sub_config_id` int(11) NOT NULL,
  `sub_price_id` int(11) NOT NULL,
  `available_llm_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `price_id` int(11) NOT NULL,
  `item_duration_month` int(11) NOT NULL,
  `duration_in_months_id` int(11) DEFAULT NULL,
  `duration_discount` double NOT NULL,
  `final_price` double NOT NULL,
  `agent_subscription_id` int(11) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `OrderItems_order_id_fkey` (`order_id`),
  KEY `OrderItems_agent_id_fkey` (`agent_id`),
  KEY `OrderItems_level_id_fkey` (`level_id`),
  KEY `OrderItems_sub_type_id_fkey` (`sub_type_id`),
  KEY `OrderItems_sub_feature_id_fkey` (`sub_feature_id`),
  KEY `OrderItems_sub_config_id_fkey` (`sub_config_id`),
  KEY `OrderItems_available_llm_id_fkey` (`available_llm_id`),
  KEY `OrderItems_org_id_fkey` (`org_id`),
  KEY `OrderItems_price_id_fkey` (`price_id`),
  KEY `OrderItems_duration_in_months_id_fkey` (`duration_in_months_id`),
  KEY `OrderItems_agent_subscription_id_fkey` (`agent_subscription_id`),
  KEY `OrderItems_org_user_id_fkey` (`org_user_id`),
  CONSTRAINT `OrderItems_agent_id_fkey` FOREIGN KEY (`agent_id`) REFERENCES `AgentTypes` (`agent_type_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_agent_subscription_id_fkey` FOREIGN KEY (`agent_subscription_id`) REFERENCES `AgentSubscription` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_available_llm_id_fkey` FOREIGN KEY (`available_llm_id`) REFERENCES `AgentSubscriptionAvailableLLM` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_duration_in_months_id_fkey` FOREIGN KEY (`duration_in_months_id`) REFERENCES `DurationInMonths` (`duration_in_month_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_level_id_fkey` FOREIGN KEY (`level_id`) REFERENCES `AgentLevel` (`level_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order` (`order_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_price_id_fkey` FOREIGN KEY (`price_id`) REFERENCES `AgentPrices` (`price_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_sub_config_id_fkey` FOREIGN KEY (`sub_config_id`) REFERENCES `SubscriptionConfiguration` (`config_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_sub_feature_id_fkey` FOREIGN KEY (`sub_feature_id`) REFERENCES `SubscriptionFeatures` (`feature_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrderItems_sub_type_id_fkey` FOREIGN KEY (`sub_type_id`) REFERENCES `SubscriptionType` (`sub_type_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderItems`
--

LOCK TABLES `OrderItems` WRITE;
/*!40000 ALTER TABLE `OrderItems` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrderItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderStatus`
--

DROP TABLE IF EXISTS `OrderStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderStatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `status` varchar(191) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `OrderStatus_order_id_fkey` (`order_id`),
  CONSTRAINT `OrderStatus_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order` (`order_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderStatus`
--

LOCK TABLES `OrderStatus` WRITE;
/*!40000 ALTER TABLE `OrderStatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrderStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgTrainingFilesLog`
--

DROP TABLE IF EXISTS `OrgTrainingFilesLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgTrainingFilesLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(191) NOT NULL,
  `file_size` double NOT NULL,
  `file_type` varchar(191) NOT NULL,
  `org_agent_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `agent_version_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `OrgTrainingFilesLog_id_key` (`id`),
  KEY `OrgTrainingFilesLog_org_agent_id_fkey` (`org_agent_id`),
  KEY `OrgTrainingFilesLog_org_id_fkey` (`org_id`),
  KEY `OrgTrainingFilesLog_org_user_id_fkey` (`org_user_id`),
  KEY `OrgTrainingFilesLog_agent_version_id_fkey` (`agent_version_id`),
  CONSTRAINT `OrgTrainingFilesLog_agent_version_id_fkey` FOREIGN KEY (`agent_version_id`) REFERENCES `AgentVersions` (`version_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrgTrainingFilesLog_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `OrgTrainingFilesLog_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `OrgTrainingFilesLog_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgTrainingFilesLog`
--

LOCK TABLES `OrgTrainingFilesLog` WRITE;
/*!40000 ALTER TABLE `OrgTrainingFilesLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgTrainingFilesLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrganisationUserAgents`
--

DROP TABLE IF EXISTS `OrganisationUserAgents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrganisationUserAgents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_user_id` int(11) NOT NULL,
  `org_agent_id` int(11) NOT NULL,
  `version_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `OrganisationUserAgents_org_user_id_fkey` (`org_user_id`),
  KEY `OrganisationUserAgents_org_agent_id_fkey` (`org_agent_id`),
  CONSTRAINT `OrganisationUserAgents_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `OrganisationUserAgents_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrganisationUserAgents`
--

LOCK TABLES `OrganisationUserAgents` WRITE;
/*!40000 ALTER TABLE `OrganisationUserAgents` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrganisationUserAgents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organization`
--

DROP TABLE IF EXISTS `Organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `org_name` varchar(191) NOT NULL,
  `website` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `currency_type` varchar(191) DEFAULT NULL,
  `contact` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `org_external_name` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Organization_email_key` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organization`
--

LOCK TABLES `Organization` WRITE;
/*!40000 ALTER TABLE `Organization` DISABLE KEYS */;
INSERT INTO `Organization` VALUES (1,1,'ibacustech','qq','qq','qq','qq','qq','qq','qq','2024-12-16 17:49:37.296','2024-12-16 17:49:37.296',NULL),(2,1,'ibacustechlabs',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-12-19 11:24:42.279','2024-12-19 11:24:42.279',NULL),(3,1,'gmail',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-12-20 08:06:33.303','2024-12-20 08:06:33.303','Greenestep');
/*!40000 ALTER TABLE `Organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrganizationAgents`
--

DROP TABLE IF EXISTS `OrganizationAgents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrganizationAgents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_item_id` int(11) DEFAULT NULL,
  `agent_name` varchar(191) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `publisher_url` varchar(191) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `user_limit` int(11) NOT NULL,
  `visibility_info_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `org_agent_description` varchar(191) NOT NULL,
  `org_agent_uuid` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `OrganizationAgents_org_agent_uuid_key` (`org_agent_uuid`),
  KEY `OrganizationAgents_visibility_info_id_fkey` (`visibility_info_id`),
  KEY `OrganizationAgents_order_item_id_fkey` (`order_item_id`),
  KEY `OrganizationAgents_purchase_id_fkey` (`purchase_id`),
  KEY `OrganizationAgents_order_id_fkey` (`order_id`),
  KEY `OrganizationAgents_org_id_fkey` (`org_id`),
  CONSTRAINT `OrganizationAgents_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order` (`order_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OrganizationAgents_order_item_id_fkey` FOREIGN KEY (`order_item_id`) REFERENCES `OrderItems` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OrganizationAgents_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OrganizationAgents_purchase_id_fkey` FOREIGN KEY (`purchase_id`) REFERENCES `AgentPurchase` (`purchase_id`) ON UPDATE CASCADE,
  CONSTRAINT `OrganizationAgents_visibility_info_id_fkey` FOREIGN KEY (`visibility_info_id`) REFERENCES `VisibilityInfo` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrganizationAgents`
--

LOCK TABLES `OrganizationAgents` WRITE;
/*!40000 ALTER TABLE `OrganizationAgents` DISABLE KEYS */;
INSERT INTO `OrganizationAgents` VALUES (4,NULL,'Helper agent',1,1,NULL,'none',3,10000,1,'2024-12-23 11:28:36.478','2024-12-23 11:28:36.478','this is an agent','f5b8b841-c989-4f8d-8064-2fcf835da407'),(5,NULL,'Support agent',1,1,NULL,'none',3,10000,1,'2024-12-23 11:28:36.484','2024-12-23 11:28:36.484','this is an agent','4762ceba-dbb1-48ea-aead-6eb157fd5fde'),(6,NULL,'Sales agent',1,1,NULL,'none',3,10000,1,'2024-12-23 11:29:23.262','2024-12-23 11:29:23.262','this is an agent','987c9b6c-ee36-4990-a7f0-de592e84d883'),(7,NULL,'Support agent',1,1,NULL,'none',3,10000,1,'2024-12-23 11:29:23.266','2024-12-23 11:29:23.266','this is an agent','1c3c7ffb-4cb1-4494-b452-72e26dcb0cea');
/*!40000 ALTER TABLE `OrganizationAgents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrganizationLLMEnabledInfo`
--

DROP TABLE IF EXISTS `OrganizationLLMEnabledInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrganizationLLMEnabledInfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL,
  `user_defined_name` varchar(191) NOT NULL,
  `org_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `org_secrets_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `OrganizationLLMEnabledInfo_org_id_fkey` (`org_id`),
  KEY `OrganizationLLMEnabledInfo_org_secrets_id_fkey` (`org_secrets_id`),
  CONSTRAINT `OrganizationLLMEnabledInfo_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `OrganizationLLMEnabledInfo_org_secrets_id_fkey` FOREIGN KEY (`org_secrets_id`) REFERENCES `OrganizationSecrets` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrganizationLLMEnabledInfo`
--

LOCK TABLES `OrganizationLLMEnabledInfo` WRITE;
/*!40000 ALTER TABLE `OrganizationLLMEnabledInfo` DISABLE KEYS */;
INSERT INTO `OrganizationLLMEnabledInfo` VALUES (1,1,'Chat gpt',3,'2024-12-24 11:36:28.095','2024-12-24 11:36:28.095',NULL);
/*!40000 ALTER TABLE `OrganizationLLMEnabledInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrganizationPosition`
--

DROP TABLE IF EXISTS `OrganizationPosition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrganizationPosition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position_name` varchar(191) NOT NULL,
  `position_value` varchar(191) NOT NULL,
  `allowed_features` varchar(191) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrganizationPosition`
--

LOCK TABLES `OrganizationPosition` WRITE;
/*!40000 ALTER TABLE `OrganizationPosition` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrganizationPosition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrganizationSecrets`
--

DROP TABLE IF EXISTS `OrganizationSecrets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrganizationSecrets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `variable_id` int(11) NOT NULL,
  `variable_values` varchar(191) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `variable_active` tinyint(1) NOT NULL,
  `variable_name` varchar(191) DEFAULT NULL,
  `org_id` int(11) DEFAULT NULL,
  `org_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `OrganizationSecrets_variable_id_fkey` (`variable_id`),
  KEY `OrganizationSecrets_org_id_fkey` (`org_id`),
  KEY `OrganizationSecrets_org_user_id_fkey` (`org_user_id`),
  CONSTRAINT `OrganizationSecrets_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OrganizationSecrets_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `OrganizationSecrets_variable_id_fkey` FOREIGN KEY (`variable_id`) REFERENCES `VariableInfo` (`variable_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrganizationSecrets`
--

LOCK TABLES `OrganizationSecrets` WRITE;
/*!40000 ALTER TABLE `OrganizationSecrets` DISABLE KEYS */;
INSERT INTO `OrganizationSecrets` VALUES (1,1,'zsgsgfdsfgsdg','2024-12-20 14:23:04.595','2024-12-20 14:23:04.595',1,NULL,3,2),(2,2,'asgdsgdgfdg','2024-12-20 14:23:18.086','2024-12-20 14:23:18.086',1,NULL,3,2),(3,3,'sdfsfsfsf','2024-12-20 14:23:33.360','2024-12-20 14:23:33.360',1,NULL,3,2),(4,4,'gfdgsdgdfg','2024-12-20 14:23:50.095','2024-12-20 14:23:50.095',1,NULL,3,2);
/*!40000 ALTER TABLE `OrganizationSecrets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrganizationUserPosition`
--

DROP TABLE IF EXISTS `OrganizationUserPosition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrganizationUserPosition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `org_position_id` int(11) NOT NULL,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `OrganizationUserPosition_org_position_id_fkey` (`org_position_id`),
  KEY `OrganizationUserPosition_org_user_id_fkey` (`org_user_id`),
  CONSTRAINT `OrganizationUserPosition_org_position_id_fkey` FOREIGN KEY (`org_position_id`) REFERENCES `OrganizationPosition` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `OrganizationUserPosition_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers` (`org_user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrganizationUserPosition`
--

LOCK TABLES `OrganizationUserPosition` WRITE;
/*!40000 ALTER TABLE `OrganizationUserPosition` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrganizationUserPosition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrganizationUsers`
--

DROP TABLE IF EXISTS `OrganizationUsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrganizationUsers` (
  `org_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `org_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`org_user_id`),
  KEY `OrganizationUsers_org_id_fkey` (`org_id`),
  KEY `OrganizationUsers_user_id_fkey` (`user_id`),
  CONSTRAINT `OrganizationUsers_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `OrganizationUsers_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrganizationUsers`
--

LOCK TABLES `OrganizationUsers` WRITE;
/*!40000 ALTER TABLE `OrganizationUsers` DISABLE KEYS */;
INSERT INTO `OrganizationUsers` VALUES (1,2,2,0,'2024-12-19 11:24:42.286','2024-12-19 11:24:42.286'),(2,3,3,0,'2024-12-20 08:06:33.305','2024-12-20 08:06:33.305'),(3,3,4,0,'2024-12-23 05:06:26.018','2024-12-23 05:06:26.018');
/*!40000 ALTER TABLE `OrganizationUsers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SubscriptionConfiguration`
--

DROP TABLE IF EXISTS `SubscriptionConfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SubscriptionConfiguration` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `sitemap_depth` int(11) NOT NULL,
  `document_size` int(11) NOT NULL,
  `number_of_documents` int(11) NOT NULL,
  `acess_users` int(11) DEFAULT NULL,
  `access_type` enum('limited','unlimited') NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`config_id`),
  KEY `SubscriptionConfiguration_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `SubscriptionConfiguration_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubscriptionConfiguration`
--

LOCK TABLES `SubscriptionConfiguration` WRITE;
/*!40000 ALTER TABLE `SubscriptionConfiguration` DISABLE KEYS */;
INSERT INTO `SubscriptionConfiguration` VALUES (1,2,100,5,NULL,'unlimited',NULL,'2024-12-16 15:49:48.244','2024-12-16 15:49:48.244'),(2,4,500,10,NULL,'unlimited',NULL,'2024-12-16 15:50:17.221','2024-12-16 15:50:17.221');
/*!40000 ALTER TABLE `SubscriptionConfiguration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SubscriptionFeatures`
--

DROP TABLE IF EXISTS `SubscriptionFeatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SubscriptionFeatures` (
  `feature_id` int(11) NOT NULL AUTO_INCREMENT,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`feature_id`),
  KEY `SubscriptionFeatures_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `SubscriptionFeatures_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubscriptionFeatures`
--

LOCK TABLES `SubscriptionFeatures` WRITE;
/*!40000 ALTER TABLE `SubscriptionFeatures` DISABLE KEYS */;
INSERT INTO `SubscriptionFeatures` VALUES (1,NULL,'2024-12-16 15:43:16.787','2024-12-16 15:43:16.787'),(2,NULL,'2024-12-16 15:43:23.143','2024-12-16 15:43:23.143'),(3,NULL,'2024-12-16 15:43:32.243','2024-12-16 15:43:32.243'),(4,NULL,'2024-12-16 15:43:39.477','2024-12-16 15:43:39.477');
/*!40000 ALTER TABLE `SubscriptionFeatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SubscriptionFeaturesInfo`
--

DROP TABLE IF EXISTS `SubscriptionFeaturesInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SubscriptionFeaturesInfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `feature_name` varchar(191) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `sub_feature_id` int(11) NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `SubscriptionFeaturesInfo_super_admin_id_fkey` (`super_admin_id`),
  KEY `SubscriptionFeaturesInfo_sub_feature_id_fkey` (`sub_feature_id`),
  CONSTRAINT `SubscriptionFeaturesInfo_sub_feature_id_fkey` FOREIGN KEY (`sub_feature_id`) REFERENCES `SubscriptionFeatures` (`feature_id`) ON UPDATE CASCADE,
  CONSTRAINT `SubscriptionFeaturesInfo_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubscriptionFeaturesInfo`
--

LOCK TABLES `SubscriptionFeaturesInfo` WRITE;
/*!40000 ALTER TABLE `SubscriptionFeaturesInfo` DISABLE KEYS */;
INSERT INTO `SubscriptionFeaturesInfo` VALUES (1,'Feature',1,1,NULL,'2024-12-16 15:44:10.077','2024-12-16 15:44:10.077'),(2,'LLMProviders',1,1,NULL,'2024-12-16 15:44:30.019','2024-12-16 15:44:30.019'),(3,'LLMProviders',1,2,NULL,'2024-12-16 15:44:49.499','2024-12-16 15:44:49.499'),(4,'SubscriptionFeaturesInfo',1,2,NULL,'2024-12-16 15:48:36.466','2024-12-16 15:48:36.466'),(5,'SubscriptionFeaturesInfo',1,3,NULL,'2024-12-16 15:48:50.871','2024-12-16 15:48:50.871'),(6,'SubscriptionFeaturesInfo',1,3,NULL,'2024-12-16 15:49:06.830','2024-12-16 15:49:06.830');
/*!40000 ALTER TABLE `SubscriptionFeaturesInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SubscriptionType`
--

DROP TABLE IF EXISTS `SubscriptionType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SubscriptionType` (
  `sub_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(191) NOT NULL,
  `order` int(11) NOT NULL,
  `disable` tinyint(1) NOT NULL,
  `super_admin_id` int(11) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`sub_type_id`),
  KEY `SubscriptionType_super_admin_id_fkey` (`super_admin_id`),
  CONSTRAINT `SubscriptionType_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers` (`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubscriptionType`
--

LOCK TABLES `SubscriptionType` WRITE;
/*!40000 ALTER TABLE `SubscriptionType` DISABLE KEYS */;
INSERT INTO `SubscriptionType` VALUES (1,'Free',0,0,NULL,'2024-12-16 15:42:34.648','2024-12-16 15:42:34.648'),(2,'Basic',1,0,NULL,'2024-12-16 15:42:46.282','2024-12-16 15:42:46.282'),(3,'Advanced',2,0,NULL,'2024-12-16 15:42:59.907','2024-12-16 15:42:59.907');
/*!40000 ALTER TABLE `SubscriptionType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SuperAdminUsers`
--

DROP TABLE IF EXISTS `SuperAdminUsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SuperAdminUsers` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `user_id` int(11) NOT NULL,
  `user_position` int(11) NOT NULL,
  `disable` tinyint(1) NOT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `SuperAdminUsers_user_id_fkey` (`user_id`),
  CONSTRAINT `SuperAdminUsers_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SuperAdminUsers`
--

LOCK TABLES `SuperAdminUsers` WRITE;
/*!40000 ALTER TABLE `SuperAdminUsers` DISABLE KEYS */;
/*!40000 ALTER TABLE `SuperAdminUsers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `username` varchar(191) NOT NULL,
  `display_picture` varchar(191) DEFAULT NULL,
  `user_type` varchar(191) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `User_email_key` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (2,'aswin@ibacustechlabs.in','Aswin Sasikumar','',NULL,'2024-12-19 11:24:42.226','2024-12-19 11:24:42.226'),(3,'test.ibtlabs@gmail.com','TEST','https://lh3.googleusercontent.com/a/ACg8ocI3Ck7ReRl74IHg-HWtWUDba35_6WFfcwAS9OGeBHap0WQPXw=s96-c','USER','2024-12-20 08:06:33.280','2024-12-20 08:06:33.280'),(4,'ashvinachu097@gmail.com','Ashvin S','https://lh3.googleusercontent.com/a/ACg8ocJqWm5OAKFoN1kI25tjlpjQFM5J13hocy1Ke5ljgxBFcjyDbrJK=s96-c','USER','2024-12-23 05:06:25.983','2024-12-23 05:06:25.983');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserLog`
--

DROP TABLE IF EXISTS `UserLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lat_long` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `language` varchar(191) DEFAULT NULL,
  `operating_system` varchar(191) DEFAULT NULL,
  `ip` varchar(191) DEFAULT NULL,
  `accessed_app_type` varchar(191) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `browser` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `UserLog_user_id_fkey` (`user_id`),
  CONSTRAINT `UserLog_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserLog`
--

LOCK TABLES `UserLog` WRITE;
/*!40000 ALTER TABLE `UserLog` DISABLE KEYS */;
INSERT INTO `UserLog` VALUES (1,NULL,NULL,'en-GB,en-US;q=0.9,en;q=0.8','Linux','::1','Web',2,'2024-12-19 11:24:42.268','Chrome'),(2,NULL,NULL,'en-GB,en-US;q=0.9,en;q=0.8','Linux','::1','Web',3,'2024-12-20 08:06:33.301','Chrome'),(3,NULL,NULL,'en-GB,en-US;q=0.9,en;q=0.8','Android','::1','Mobile',4,'2024-12-23 05:06:26.009','Mobile Chrome');
/*!40000 ALTER TABLE `UserLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VariableInfo`
--

DROP TABLE IF EXISTS `VariableInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VariableInfo` (
  `variable_id` int(11) NOT NULL AUTO_INCREMENT,
  `variable_name` varchar(191) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`variable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VariableInfo`
--

LOCK TABLES `VariableInfo` WRITE;
/*!40000 ALTER TABLE `VariableInfo` DISABLE KEYS */;
INSERT INTO `VariableInfo` VALUES (1,'JA_KEY','2024-12-20 14:16:34.657','2024-12-20 14:16:34.657'),(2,'Chat GPT Key','2024-12-20 14:16:57.478','2024-12-20 14:16:57.478'),(3,'lama AI Key','2024-12-20 14:17:10.260','2024-12-20 14:17:10.260'),(4,'Gemini','2024-12-20 14:17:37.748','2024-12-20 14:17:37.748');
/*!40000 ALTER TABLE `VariableInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VisibilityInfo`
--

DROP TABLE IF EXISTS `VisibilityInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VisibilityInfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visibility_name` varchar(191) NOT NULL,
  `visibility_value` int(11) NOT NULL DEFAULT 0,
  `org_user_id` int(11) NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updated_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VisibilityInfo`
--

LOCK TABLES `VisibilityInfo` WRITE;
/*!40000 ALTER TABLE `VisibilityInfo` DISABLE KEYS */;
INSERT INTO `VisibilityInfo` VALUES (1,'Public',0,1,'2024-12-16 17:52:41.366','2024-12-16 17:52:41.366'),(2,'Private',1,1,'2024-12-16 17:52:58.325','2024-12-16 17:52:58.325');
/*!40000 ALTER TABLE `VisibilityInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_OrganizationLLMEnabledInfoToOrganizationUsers`
--

DROP TABLE IF EXISTS `_OrganizationLLMEnabledInfoToOrganizationUsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_OrganizationLLMEnabledInfoToOrganizationUsers` (
  `A` int(11) NOT NULL,
  `B` int(11) NOT NULL,
  UNIQUE KEY `_OrganizationLLMEnabledInfoToOrganizationUsers_AB_unique` (`A`,`B`),
  KEY `_OrganizationLLMEnabledInfoToOrganizationUsers_B_index` (`B`),
  CONSTRAINT `_OrganizationLLMEnabledInfoToOrganizationUsers_A_fkey` FOREIGN KEY (`A`) REFERENCES `OrganizationLLMEnabledInfo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `_OrganizationLLMEnabledInfoToOrganizationUsers_B_fkey` FOREIGN KEY (`B`) REFERENCES `OrganizationUsers` (`org_user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_OrganizationLLMEnabledInfoToOrganizationUsers`
--

LOCK TABLES `_OrganizationLLMEnabledInfoToOrganizationUsers` WRITE;
/*!40000 ALTER TABLE `_OrganizationLLMEnabledInfoToOrganizationUsers` DISABLE KEYS */;
/*!40000 ALTER TABLE `_OrganizationLLMEnabledInfoToOrganizationUsers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('0a1b55c5-e864-4fe4-9800-f80852c4c0e5','057ed6050cea62fe6561d86fa81d2247c9cce1101d35aa93790d70b7ba3a8100','2024-12-20 08:59:50.451','20241220085950_o',NULL,NULL,'2024-12-20 08:59:50.445',1),('136954c9-0d06-4d82-b488-f09ccb8f5a08','fadc3be9142da31a20b978d1c9ba894742c468f874733fa6daf0a3797de9b0b8','2024-12-17 09:29:01.309','20241217091244_init',NULL,NULL,'2024-12-17 09:29:01.268',1),('20452a07-618e-4edb-8f19-002c623fe333','943f06b488e301311ceab24f06036647d7be0b8e80f437ef2c12edaf7f2709d3','2024-12-24 05:30:38.535','20241224053038_new',NULL,NULL,'2024-12-24 05:30:38.525',1),('23d5049e-6c14-488d-8ddd-a2fbfe51966b','c15e79925dcedcd1cf354d4591e99768bb1910b902fc2d5cfdf449887d3f46bc','2024-12-24 05:46:45.720','20241224054645_nm',NULL,NULL,'2024-12-24 05:46:45.714',1),('3ec56cce-a1b7-4726-a5d6-e2f73a169478','e8d2dc561ed9ccd0c816f822facb9d60443eb5d8ffa05fedd8ecc73833382e49','2024-12-20 08:57:14.705','20241220085714_dev',NULL,NULL,'2024-12-20 08:57:14.680',1),('3ec84bc4-8a4c-443d-b01f-ddf3452791ff','6d3ba5b1f8605642ec0c0bd4c5d9002bcbd104f0a3f6a52b7f59b896946039cc','2024-12-19 07:21:04.903','20241219072104_table_add',NULL,NULL,'2024-12-19 07:21:04.880',1),('50694585-e4ac-49ec-b3a5-16dd62bccd97','7170e533cfd6f29d62778234993fbdb475f63a025a0698b44c6824764feae122','2024-12-20 08:50:34.964','20241220085034_llm_update',NULL,NULL,'2024-12-20 08:50:34.947',1),('577e7d0b-5f1c-492b-8835-d8c1f9dd6527','79bb4b98b405f19fced9d56b353ea57b21cb620d44db02d4a07886ef1afd9f1d','2024-12-23 11:11:53.607','20241223111153_',NULL,NULL,'2024-12-23 11:11:53.586',1),('6584f249-84a1-403f-9ab0-0e1e9954fd44','0a541116127914a79f341d67cc9f4d0f588a3ab93088024648d2e9671b3daab8','2024-12-20 08:43:25.619','20241220084325_secrets_table',NULL,NULL,'2024-12-20 08:43:25.612',1),('66fd09b6-72fa-4946-b34c-c33838709a40','bcaf353e68d6061bec65b0d6279f688b3975ecf6dfc3cff5895309e589be5e24','2024-12-16 10:06:23.335','20241216100622_',NULL,NULL,'2024-12-16 10:06:22.480',1),('80f165bb-79d7-4a8b-ba37-b13dbcc9afdf','415612a4cb11c92583b6dd963b0b560684ea70b1a6fc7dde72b1ff51a2de588a','2024-12-24 05:29:18.099','20241224052918_update',NULL,NULL,'2024-12-24 05:29:18.076',1),('88874dc1-31f3-45bc-a1a9-23f01218ac74','1db49ffb43db67817fd04e264648039accfeddc27bc9b5d8a4f407370271bb4c','2024-12-24 06:11:26.864','20241224061126_update',NULL,NULL,'2024-12-24 06:11:26.847',1),('a373d590-c096-443a-9fea-2207d91749e7','d995033312c8fa27f385c5b77f896625c2d8b67aff3f70e085636f8acd9b4099','2024-12-16 12:17:42.380','20241216121742_new_mod',NULL,NULL,'2024-12-16 12:17:42.205',1),('ccd281a5-1b1f-43b4-8e2e-1d2bf0a63b77','985671da9b9d0a80b568b064499b82de98074a29396609ef0961c2503d1d305e','2024-12-23 11:15:57.596','20241223111557_new',NULL,NULL,'2024-12-23 11:15:57.567',1),('eaf1afb9-a3dc-4fbb-aad0-418f8cf942f9','8a7582167022b73f1ee37a3ade22c02143f5face75ce4f3e745500ffd50de67e','2024-12-16 10:17:49.756','20241216101749_new',NULL,NULL,'2024-12-16 10:17:49.741',1),('ec269030-d9f0-4102-90f4-0c7defc4b401','3c0518d88d555701a253d3d36197196a8e2c98e121cc58ac185ec3d973a7c3a4','2024-12-16 10:37:39.816','20241216103739_new_dep',NULL,NULL,'2024-12-16 10:37:39.804',1),('fc7ea2c5-4a30-4978-bfd8-5a821c3f940e','580d39dc8f931a71105f1baf412660a1b8d4e5fcdc101b350feccbcfacc55f96','2024-12-23 12:56:52.721','20241223125652_nw_update',NULL,NULL,'2024-12-23 12:56:52.663',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-24 14:57:35
