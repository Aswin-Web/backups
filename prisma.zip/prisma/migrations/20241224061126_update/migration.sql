-- AlterTable
ALTER TABLE `OrganizationLLMEnabledInfo` ADD COLUMN `org_secrets_id` INTEGER NULL;

-- AddForeignKey
ALTER TABLE `OrganizationLLMEnabledInfo` ADD CONSTRAINT `OrganizationLLMEnabledInfo_org_secrets_id_fkey` FOREIGN KEY (`org_secrets_id`) REFERENCES `OrganizationSecrets`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
