-- AlterTable
ALTER TABLE `AgentVersions` MODIFY `raw_url` VARCHAR(191) NULL,
    MODIFY `train_url` VARCHAR(191) NULL;
