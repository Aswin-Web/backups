-- DropForeignKey
ALTER TABLE `SubscriptionFeaturesInfo` DROP FOREIGN KEY `SubscriptionFeaturesInfo_id_fkey`;

-- AddForeignKey
ALTER TABLE `SubscriptionFeaturesInfo` ADD CONSTRAINT `SubscriptionFeaturesInfo_sub_feature_id_fkey` FOREIGN KEY (`sub_feature_id`) REFERENCES `SubscriptionFeatures`(`feature_id`) ON DELETE RESTRICT ON UPDATE CASCADE;
