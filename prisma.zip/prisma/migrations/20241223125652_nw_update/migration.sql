/*
  Warnings:

  - The primary key for the `ChatGroups` table will be changed. If it partially fails, the table could be left without primary key constraint.

*/
-- DropForeignKey
ALTER TABLE `ChatConversation` DROP FOREIGN KEY `ChatConversation_chat_group_id_fkey`;

-- AlterTable
ALTER TABLE `ChatConversation` MODIFY `chat_group_id` VARCHAR(191) NOT NULL;

-- AlterTable
ALTER TABLE `ChatGroups` DROP PRIMARY KEY,
    MODIFY `chat_group_id` VARCHAR(191) NOT NULL,
    ADD PRIMARY KEY (`chat_group_id`);

-- AddForeignKey
ALTER TABLE `ChatConversation` ADD CONSTRAINT `ChatConversation_chat_group_id_fkey` FOREIGN KEY (`chat_group_id`) REFERENCES `ChatGroups`(`chat_group_id`) ON DELETE RESTRICT ON UPDATE CASCADE;
