/*
  Warnings:

  - You are about to drop the column `agent_uuid` on the `OrganizationAgents` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[org_agent_uuid]` on the table `OrganizationAgents` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `org_agent_description` to the `OrganizationAgents` table without a default value. This is not possible if the table is not empty.
  - The required column `org_agent_uuid` was added to the `OrganizationAgents` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.

*/
-- DropIndex
DROP INDEX `OrganizationAgents_agent_uuid_key` ON `OrganizationAgents`;

-- AlterTable
ALTER TABLE `OrganizationAgents` DROP COLUMN `agent_uuid`,
    ADD COLUMN `org_agent_description` VARCHAR(191) NOT NULL,
    ADD COLUMN `org_agent_uuid` VARCHAR(191) NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX `OrganizationAgents_org_agent_uuid_key` ON `OrganizationAgents`(`org_agent_uuid`);
