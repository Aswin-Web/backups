-- AlterTable
ALTER TABLE `OrganizationSecrets` ADD COLUMN `org_id` INTEGER NULL,
    ADD COLUMN `org_user_id` INTEGER NULL;

-- AddForeignKey
ALTER TABLE `OrganizationSecrets` ADD CONSTRAINT `OrganizationSecrets_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationSecrets` ADD CONSTRAINT `OrganizationSecrets_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE SET NULL ON UPDATE CASCADE;
