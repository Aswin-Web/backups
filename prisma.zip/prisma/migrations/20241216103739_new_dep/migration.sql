-- AddForeignKey
ALTER TABLE `AgentPrices` ADD CONSTRAINT `AgentPrices_currency_id_fkey` FOREIGN KEY (`currency_id`) REFERENCES `Currency`(`currency_id`) ON DELETE RESTRICT ON UPDATE CASCADE;
