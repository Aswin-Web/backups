-- CreateTable
CREATE TABLE `User` (
    `user_id` INTEGER NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(191) NOT NULL,
    `username` VARCHAR(191) NOT NULL,
    `display_picture` VARCHAR(191) NULL,
    `user_type` VARCHAR(191) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `User_email_key`(`email`),
    PRIMARY KEY (`user_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `UserLog` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `lat_long` VARCHAR(191) NOT NULL,
    `country` VARCHAR(191) NOT NULL,
    `device_type` VARCHAR(191) NOT NULL,
    `language` VARCHAR(191) NOT NULL,
    `operating_system` VARCHAR(191) NOT NULL,
    `ip` VARCHAR(191) NOT NULL,
    `accessed_app_type` VARCHAR(191) NOT NULL,
    `user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Organization` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `active` BOOLEAN NOT NULL DEFAULT true,
    `org_name` VARCHAR(191) NOT NULL,
    `website` VARCHAR(191) NOT NULL,
    `country` VARCHAR(191) NOT NULL,
    `currency_type` VARCHAR(191) NOT NULL,
    `contact` VARCHAR(191) NOT NULL,
    `address` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `description` VARCHAR(191) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `Organization_email_key`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrganizationPosition` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `position_name` VARCHAR(191) NOT NULL,
    `position_value` VARCHAR(191) NOT NULL,
    `allowed_features` VARCHAR(191) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrganizationUsers` (
    `org_user_id` INTEGER NOT NULL AUTO_INCREMENT,
    `org_id` INTEGER NOT NULL,
    `user_id` INTEGER NOT NULL,
    `active` BOOLEAN NOT NULL DEFAULT false,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`org_user_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrganizationUserPosition` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `org_position_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrganizationSecrets` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `variable_id` INTEGER NOT NULL,
    `variable_values` VARCHAR(191) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `VariableInfo` (
    `variable_id` INTEGER NOT NULL AUTO_INCREMENT,
    `variable_name` VARCHAR(191) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`variable_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrganizationAgents` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `order_item_id` INTEGER NOT NULL,
    `agent_name` VARCHAR(191) NOT NULL,
    `purchase_id` INTEGER NOT NULL,
    `is_active` INTEGER NOT NULL,
    `order_id` INTEGER NOT NULL,
    `publisher_url` VARCHAR(191) NOT NULL,
    `org_id` INTEGER NOT NULL,
    `user_limit` INTEGER NOT NULL,
    `visibility_info_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentPurchase` (
    `purchase_id` INTEGER NOT NULL AUTO_INCREMENT,
    `start_date` DATETIME(3) NOT NULL,
    `end_date` DATETIME(3) NOT NULL,
    `order_item_id` INTEGER NOT NULL,
    `org_id` INTEGER NOT NULL,
    `order_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`purchase_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrganisationUserAgents` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `org_user_id` INTEGER NOT NULL,
    `org_agent_id` INTEGER NOT NULL,
    `version_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentVersions` (
    `version_id` INTEGER NOT NULL AUTO_INCREMENT,
    `version_name` VARCHAR(191) NOT NULL,
    `agent_uuid` VARCHAR(191) NULL,
    `raw_url` VARCHAR(191) NOT NULL,
    `train_url` VARCHAR(191) NOT NULL,
    `org_id` INTEGER NOT NULL,
    `org_agent_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`version_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrgTrainingFilesLog` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `filename` VARCHAR(191) NOT NULL,
    `file_size` DOUBLE NOT NULL,
    `file_type` VARCHAR(191) NOT NULL,
    `org_agent_id` INTEGER NOT NULL,
    `org_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `agent_version_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `OrgTrainingFilesLog_id_key`(`id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `VisibilityInfo` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `visibility_name` VARCHAR(191) NOT NULL,
    `visibility_value` INTEGER NOT NULL DEFAULT 0,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ChatGroups` (
    `chat_group_id` INTEGER NOT NULL AUTO_INCREMENT,
    `chat_name` INTEGER NOT NULL,
    `org_user_agents_id` INTEGER NOT NULL,
    `org_agent_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`chat_group_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ChatConversation` (
    `message_id` INTEGER NOT NULL AUTO_INCREMENT,
    `chat_group_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `llm_type_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`message_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrganizationLLMEnabledInfo` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `status` BOOLEAN NOT NULL,
    `user_defined_name` VARCHAR(191) NOT NULL,
    `org_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SuperAdminUsers` (
    `admin_id` INTEGER NOT NULL AUTO_INCREMENT,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `user_id` INTEGER NOT NULL,
    `user_position` INTEGER NOT NULL,
    `disable` BOOLEAN NOT NULL,

    PRIMARY KEY (`admin_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentTypes` (
    `agent_type_id` INTEGER NOT NULL AUTO_INCREMENT,
    `internal_name` VARCHAR(191) NOT NULL,
    `external_name` VARCHAR(191) NULL,
    `description` VARCHAR(191) NULL,
    `agent_icon` VARCHAR(191) NULL,
    `python_base_url` VARCHAR(191) NULL,
    `disable` BOOLEAN NOT NULL DEFAULT true,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`agent_type_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentLevel` (
    `level_id` INTEGER NOT NULL AUTO_INCREMENT,
    `super_admin_id` INTEGER NULL,
    `level_name` VARCHAR(191) NOT NULL,
    `level_descp` VARCHAR(191) NOT NULL,
    `level_type` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`level_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SubscriptionFeatures` (
    `feature_id` INTEGER NOT NULL AUTO_INCREMENT,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`feature_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SubscriptionFeaturesInfo` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `feature_name` VARCHAR(191) NOT NULL,
    `enabled` BOOLEAN NOT NULL,
    `sub_feature_id` INTEGER NOT NULL,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentSubscriptionPrices` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentPrices` (
    `price_id` INTEGER NOT NULL AUTO_INCREMENT,
    `agent_sub_prices_id` INTEGER NOT NULL,
    `currency_id` INTEGER NOT NULL,
    `is_single_time_per_domain` BOOLEAN NOT NULL,
    `is_paid` BOOLEAN NOT NULL,
    `price` DOUBLE NOT NULL,
    `current` BOOLEAN NOT NULL,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`price_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Currency` (
    `currency_id` INTEGER NOT NULL AUTO_INCREMENT,
    `currency_name` VARCHAR(191) NOT NULL,
    `currency_code` VARCHAR(191) NOT NULL,
    `is_global` BOOLEAN NOT NULL,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`currency_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SubscriptionType` (
    `sub_type_id` INTEGER NOT NULL AUTO_INCREMENT,
    `sub_name` VARCHAR(191) NOT NULL,
    `order` INTEGER NOT NULL,
    `disable` BOOLEAN NOT NULL,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`sub_type_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SubscriptionConfiguration` (
    `config_id` INTEGER NOT NULL AUTO_INCREMENT,
    `sitemap_depth` INTEGER NOT NULL,
    `document_size` INTEGER NOT NULL,
    `number_of_documents` INTEGER NOT NULL,
    `acess_users` INTEGER NULL,
    `access_type` ENUM('limited', 'unlimited') NOT NULL,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`config_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentSubscriptionAvailableLLM` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AvailableListAtLLMSubscription` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `agent_subscription_available_llm_id` INTEGER NOT NULL,
    `llm_providers_id` INTEGER NOT NULL,
    `status` BOOLEAN NOT NULL,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AgentSubscription` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `agent_id` INTEGER NOT NULL,
    `level_id` INTEGER NOT NULL,
    `sub_type_id` INTEGER NOT NULL,
    `sub_feature_id` INTEGER NOT NULL,
    `sub_config_id` INTEGER NOT NULL,
    `sub_price_id` INTEGER NOT NULL,
    `available_llm_id` INTEGER NOT NULL,
    `super_admin_id` INTEGER NULL,
    `plan_name` VARCHAR(191) NOT NULL,
    `disable` BOOLEAN NOT NULL,
    `access_user_limit` INTEGER NOT NULL,
    `limit_level` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Order` (
    `order_id` INTEGER NOT NULL AUTO_INCREMENT,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `coupon_id` INTEGER NULL,
    `order_status` VARCHAR(191) NOT NULL,
    `coupon_discount` DOUBLE NOT NULL,
    `final_price` DOUBLE NOT NULL,
    `payment_status` VARCHAR(191) NOT NULL,
    `ext_payment_info_id` INTEGER NOT NULL,
    `billing_info_id` INTEGER NOT NULL,

    PRIMARY KEY (`order_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `BillingInfo` (
    `billing_info_id` INTEGER NOT NULL AUTO_INCREMENT,
    `billing_name` INTEGER NOT NULL,
    `address` VARCHAR(191) NOT NULL,
    `org_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`billing_info_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ExtPaymentInfo` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `payment_info` VARCHAR(191) NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrderStatus` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `order_id` INTEGER NOT NULL,
    `status` VARCHAR(191) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `CartItems` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `agent_subscription_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `OrderItems` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `order_id` INTEGER NOT NULL,
    `agent_id` INTEGER NOT NULL,
    `level_id` INTEGER NOT NULL,
    `sub_type_id` INTEGER NOT NULL,
    `sub_feature_id` INTEGER NOT NULL,
    `sub_config_id` INTEGER NOT NULL,
    `sub_price_id` INTEGER NOT NULL,
    `available_llm_id` INTEGER NOT NULL,
    `org_id` INTEGER NOT NULL,
    `price_id` INTEGER NOT NULL,
    `item_duration_month` INTEGER NOT NULL,
    `duration_in_months_id` INTEGER NULL,
    `duration_discount` DOUBLE NOT NULL,
    `final_price` DOUBLE NOT NULL,
    `agent_subscription_id` INTEGER NOT NULL,
    `org_user_id` INTEGER NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `DurationInMonths` (
    `duration_in_month_id` INTEGER NOT NULL AUTO_INCREMENT,
    `duration_name` VARCHAR(191) NOT NULL,
    `no_of_months` INTEGER NOT NULL,
    `discount_percent` INTEGER NOT NULL,
    `discount_price` DOUBLE NOT NULL,
    `super_admin_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`duration_in_month_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `LLMProviders` (
    `llm_id` INTEGER NOT NULL AUTO_INCREMENT,
    `llm_internal_name` VARCHAR(191) NOT NULL,
    `llm_external_name` VARCHAR(191) NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`llm_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `_OrganizationLLMEnabledInfoToOrganizationUsers` (
    `A` INTEGER NOT NULL,
    `B` INTEGER NOT NULL,

    UNIQUE INDEX `_OrganizationLLMEnabledInfoToOrganizationUsers_AB_unique`(`A`, `B`),
    INDEX `_OrganizationLLMEnabledInfoToOrganizationUsers_B_index`(`B`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `UserLog` ADD CONSTRAINT `UserLog_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationUsers` ADD CONSTRAINT `OrganizationUsers_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationUsers` ADD CONSTRAINT `OrganizationUsers_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationUserPosition` ADD CONSTRAINT `OrganizationUserPosition_org_position_id_fkey` FOREIGN KEY (`org_position_id`) REFERENCES `OrganizationPosition`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationUserPosition` ADD CONSTRAINT `OrganizationUserPosition_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationSecrets` ADD CONSTRAINT `OrganizationSecrets_variable_id_fkey` FOREIGN KEY (`variable_id`) REFERENCES `VariableInfo`(`variable_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_order_item_id_fkey` FOREIGN KEY (`order_item_id`) REFERENCES `OrderItems`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order`(`order_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_visibility_info_id_fkey` FOREIGN KEY (`visibility_info_id`) REFERENCES `VisibilityInfo`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPurchase` ADD CONSTRAINT `AgentPurchase_order_item_id_fkey` FOREIGN KEY (`order_item_id`) REFERENCES `OrderItems`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPurchase` ADD CONSTRAINT `AgentPurchase_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPurchase` ADD CONSTRAINT `AgentPurchase_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order`(`order_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganisationUserAgents` ADD CONSTRAINT `OrganisationUserAgents_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganisationUserAgents` ADD CONSTRAINT `OrganisationUserAgents_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentVersions` ADD CONSTRAINT `AgentVersions_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentVersions` ADD CONSTRAINT `AgentVersions_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentVersions` ADD CONSTRAINT `AgentVersions_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrgTrainingFilesLog` ADD CONSTRAINT `OrgTrainingFilesLog_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrgTrainingFilesLog` ADD CONSTRAINT `OrgTrainingFilesLog_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrgTrainingFilesLog` ADD CONSTRAINT `OrgTrainingFilesLog_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrgTrainingFilesLog` ADD CONSTRAINT `OrgTrainingFilesLog_agent_version_id_fkey` FOREIGN KEY (`agent_version_id`) REFERENCES `AgentVersions`(`version_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatGroups` ADD CONSTRAINT `ChatGroups_org_user_agents_id_fkey` FOREIGN KEY (`org_user_agents_id`) REFERENCES `OrganisationUserAgents`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatGroups` ADD CONSTRAINT `ChatGroups_org_agent_id_fkey` FOREIGN KEY (`org_agent_id`) REFERENCES `OrganizationAgents`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatGroups` ADD CONSTRAINT `ChatGroups_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatConversation` ADD CONSTRAINT `ChatConversation_chat_group_id_fkey` FOREIGN KEY (`chat_group_id`) REFERENCES `ChatGroups`(`chat_group_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatConversation` ADD CONSTRAINT `ChatConversation_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatConversation` ADD CONSTRAINT `ChatConversation_llm_type_id_fkey` FOREIGN KEY (`llm_type_id`) REFERENCES `OrganizationLLMEnabledInfo`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationLLMEnabledInfo` ADD CONSTRAINT `OrganizationLLMEnabledInfo_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SuperAdminUsers` ADD CONSTRAINT `SuperAdminUsers_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentTypes` ADD CONSTRAINT `AgentTypes_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentLevel` ADD CONSTRAINT `AgentLevel_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SubscriptionFeatures` ADD CONSTRAINT `SubscriptionFeatures_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SubscriptionFeaturesInfo` ADD CONSTRAINT `SubscriptionFeaturesInfo_id_fkey` FOREIGN KEY (`id`) REFERENCES `SubscriptionFeatures`(`feature_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SubscriptionFeaturesInfo` ADD CONSTRAINT `SubscriptionFeaturesInfo_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscriptionPrices` ADD CONSTRAINT `AgentSubscriptionPrices_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPrices` ADD CONSTRAINT `AgentPrices_agent_sub_prices_id_fkey` FOREIGN KEY (`agent_sub_prices_id`) REFERENCES `AgentSubscriptionPrices`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPrices` ADD CONSTRAINT `AgentPrices_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Currency` ADD CONSTRAINT `Currency_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SubscriptionType` ADD CONSTRAINT `SubscriptionType_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SubscriptionConfiguration` ADD CONSTRAINT `SubscriptionConfiguration_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscriptionAvailableLLM` ADD CONSTRAINT `AgentSubscriptionAvailableLLM_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AvailableListAtLLMSubscription` ADD CONSTRAINT `AvailableListAtLLMSubscription_agent_subscription_available_fkey` FOREIGN KEY (`agent_subscription_available_llm_id`) REFERENCES `AgentSubscriptionAvailableLLM`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AvailableListAtLLMSubscription` ADD CONSTRAINT `AvailableListAtLLMSubscription_llm_providers_id_fkey` FOREIGN KEY (`llm_providers_id`) REFERENCES `LLMProviders`(`llm_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AvailableListAtLLMSubscription` ADD CONSTRAINT `AvailableListAtLLMSubscription_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_agent_id_fkey` FOREIGN KEY (`agent_id`) REFERENCES `AgentTypes`(`agent_type_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_level_id_fkey` FOREIGN KEY (`level_id`) REFERENCES `AgentLevel`(`level_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_sub_type_id_fkey` FOREIGN KEY (`sub_type_id`) REFERENCES `SubscriptionType`(`sub_type_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_sub_feature_id_fkey` FOREIGN KEY (`sub_feature_id`) REFERENCES `SubscriptionFeatures`(`feature_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_sub_config_id_fkey` FOREIGN KEY (`sub_config_id`) REFERENCES `SubscriptionConfiguration`(`config_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_available_llm_id_fkey` FOREIGN KEY (`available_llm_id`) REFERENCES `AgentSubscriptionAvailableLLM`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_sub_price_id_fkey` FOREIGN KEY (`sub_price_id`) REFERENCES `AgentSubscriptionPrices`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentSubscription` ADD CONSTRAINT `AgentSubscription_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Order` ADD CONSTRAINT `Order_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Order` ADD CONSTRAINT `Order_ext_payment_info_id_fkey` FOREIGN KEY (`ext_payment_info_id`) REFERENCES `ExtPaymentInfo`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Order` ADD CONSTRAINT `Order_billing_info_id_fkey` FOREIGN KEY (`billing_info_id`) REFERENCES `BillingInfo`(`billing_info_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `BillingInfo` ADD CONSTRAINT `BillingInfo_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `BillingInfo` ADD CONSTRAINT `BillingInfo_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ExtPaymentInfo` ADD CONSTRAINT `ExtPaymentInfo_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderStatus` ADD CONSTRAINT `OrderStatus_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order`(`order_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `CartItems` ADD CONSTRAINT `CartItems_agent_subscription_id_fkey` FOREIGN KEY (`agent_subscription_id`) REFERENCES `AgentSubscription`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `CartItems` ADD CONSTRAINT `CartItems_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order`(`order_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_agent_id_fkey` FOREIGN KEY (`agent_id`) REFERENCES `AgentTypes`(`agent_type_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_level_id_fkey` FOREIGN KEY (`level_id`) REFERENCES `AgentLevel`(`level_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_sub_type_id_fkey` FOREIGN KEY (`sub_type_id`) REFERENCES `SubscriptionType`(`sub_type_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_sub_feature_id_fkey` FOREIGN KEY (`sub_feature_id`) REFERENCES `SubscriptionFeatures`(`feature_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_sub_config_id_fkey` FOREIGN KEY (`sub_config_id`) REFERENCES `SubscriptionConfiguration`(`config_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_available_llm_id_fkey` FOREIGN KEY (`available_llm_id`) REFERENCES `AgentSubscriptionAvailableLLM`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_price_id_fkey` FOREIGN KEY (`price_id`) REFERENCES `AgentPrices`(`price_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_duration_in_months_id_fkey` FOREIGN KEY (`duration_in_months_id`) REFERENCES `DurationInMonths`(`duration_in_month_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_agent_subscription_id_fkey` FOREIGN KEY (`agent_subscription_id`) REFERENCES `AgentSubscription`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrderItems` ADD CONSTRAINT `OrderItems_org_user_id_fkey` FOREIGN KEY (`org_user_id`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `DurationInMonths` ADD CONSTRAINT `DurationInMonths_super_admin_id_fkey` FOREIGN KEY (`super_admin_id`) REFERENCES `SuperAdminUsers`(`admin_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `_OrganizationLLMEnabledInfoToOrganizationUsers` ADD CONSTRAINT `_OrganizationLLMEnabledInfoToOrganizationUsers_A_fkey` FOREIGN KEY (`A`) REFERENCES `OrganizationLLMEnabledInfo`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `_OrganizationLLMEnabledInfoToOrganizationUsers` ADD CONSTRAINT `_OrganizationLLMEnabledInfoToOrganizationUsers_B_fkey` FOREIGN KEY (`B`) REFERENCES `OrganizationUsers`(`org_user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
