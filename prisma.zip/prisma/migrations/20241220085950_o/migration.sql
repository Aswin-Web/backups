-- AlterTable
ALTER TABLE `Organization` ADD COLUMN `org_external_name` VARCHAR(191) NULL;
