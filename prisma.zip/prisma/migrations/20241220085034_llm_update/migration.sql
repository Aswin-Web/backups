-- AlterTable
ALTER TABLE `LLMProviders` ADD COLUMN `llm_variable_id` INTEGER NULL;

-- AddForeignKey
ALTER TABLE `LLMProviders` ADD CONSTRAINT `LLMProviders_llm_variable_id_fkey` FOREIGN KEY (`llm_variable_id`) REFERENCES `VariableInfo`(`variable_id`) ON DELETE SET NULL ON UPDATE CASCADE;
