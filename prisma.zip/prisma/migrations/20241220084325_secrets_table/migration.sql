/*
  Warnings:

  - Added the required column `variable_active` to the `OrganizationSecrets` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `OrganizationSecrets` ADD COLUMN `variable_active` BOOLEAN NOT NULL,
    ADD COLUMN `variable_name` VARCHAR(191) NULL;
