-- CreateTable
CREATE TABLE `AgentVersionTrainingLogs` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `version_id` INTEGER NOT NULL,
    `training_status` ENUM('STARTED', 'PROCESSING', 'FAILED', 'FINISHED') NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `AgentVersionTrainingLogs` ADD CONSTRAINT `AgentVersionTrainingLogs_version_id_fkey` FOREIGN KEY (`version_id`) REFERENCES `AgentVersions`(`version_id`) ON DELETE RESTRICT ON UPDATE CASCADE;
