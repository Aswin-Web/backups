/*
  Warnings:

  - You are about to drop the column `device_type` on the `UserLog` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `Organization` MODIFY `website` VARCHAR(191) NULL,
    MODIFY `country` VARCHAR(191) NULL,
    MODIFY `currency_type` VARCHAR(191) NULL,
    MODIFY `contact` VARCHAR(191) NULL,
    MODIFY `address` VARCHAR(191) NULL,
    MODIFY `email` VARCHAR(191) NULL,
    MODIFY `description` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `User` MODIFY `user_type` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `UserLog` DROP COLUMN `device_type`,
    ADD COLUMN `browser` VARCHAR(191) NULL,
    MODIFY `lat_long` VARCHAR(191) NULL,
    MODIFY `country` VARCHAR(191) NULL,
    MODIFY `language` VARCHAR(191) NULL,
    MODIFY `operating_system` VARCHAR(191) NULL,
    MODIFY `ip` VARCHAR(191) NULL,
    MODIFY `accessed_app_type` VARCHAR(191) NULL;
