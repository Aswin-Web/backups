-- DropForeignKey
ALTER TABLE `ChatGroups` DROP FOREIGN KEY `ChatGroups_org_user_agents_id_fkey`;

-- AlterTable
ALTER TABLE `ChatGroups` MODIFY `org_user_agents_id` INTEGER NULL;

-- AddForeignKey
ALTER TABLE `ChatGroups` ADD CONSTRAINT `ChatGroups_org_user_agents_id_fkey` FOREIGN KEY (`org_user_agents_id`) REFERENCES `OrganisationUserAgents`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
