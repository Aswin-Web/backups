/*
  Warnings:

  - A unique constraint covering the columns `[agent_uuid]` on the table `OrganizationAgents` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `OrganizationAgents` ADD COLUMN `agent_uuid` VARCHAR(191) NULL;

-- CreateIndex
CREATE UNIQUE INDEX `OrganizationAgents_agent_uuid_key` ON `OrganizationAgents`(`agent_uuid`);
