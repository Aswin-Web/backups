-- AlterTable
ALTER TABLE `ChatGroups` MODIFY `chat_name` VARCHAR(191) NOT NULL;
