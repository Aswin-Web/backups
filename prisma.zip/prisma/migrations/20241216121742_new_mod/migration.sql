-- DropForeignKey
ALTER TABLE `AgentPurchase` DROP FOREIGN KEY `AgentPurchase_order_id_fkey`;

-- DropForeignKey
ALTER TABLE `AgentPurchase` DROP FOREIGN KEY `AgentPurchase_order_item_id_fkey`;

-- DropForeignKey
ALTER TABLE `AgentPurchase` DROP FOREIGN KEY `AgentPurchase_org_id_fkey`;

-- DropForeignKey
ALTER TABLE `OrganizationAgents` DROP FOREIGN KEY `OrganizationAgents_order_id_fkey`;

-- DropForeignKey
ALTER TABLE `OrganizationAgents` DROP FOREIGN KEY `OrganizationAgents_order_item_id_fkey`;

-- DropForeignKey
ALTER TABLE `OrganizationAgents` DROP FOREIGN KEY `OrganizationAgents_org_id_fkey`;

-- AlterTable
ALTER TABLE `AgentPurchase` MODIFY `order_item_id` INTEGER NULL,
    MODIFY `org_id` INTEGER NULL,
    MODIFY `order_id` INTEGER NULL;

-- AlterTable
ALTER TABLE `OrganizationAgents` MODIFY `order_item_id` INTEGER NULL,
    MODIFY `order_id` INTEGER NULL,
    MODIFY `org_id` INTEGER NULL;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_order_item_id_fkey` FOREIGN KEY (`order_item_id`) REFERENCES `OrderItems`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_purchase_id_fkey` FOREIGN KEY (`purchase_id`) REFERENCES `AgentPurchase`(`purchase_id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order`(`order_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `OrganizationAgents` ADD CONSTRAINT `OrganizationAgents_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPurchase` ADD CONSTRAINT `AgentPurchase_order_item_id_fkey` FOREIGN KEY (`order_item_id`) REFERENCES `OrderItems`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPurchase` ADD CONSTRAINT `AgentPurchase_org_id_fkey` FOREIGN KEY (`org_id`) REFERENCES `Organization`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `AgentPurchase` ADD CONSTRAINT `AgentPurchase_order_id_fkey` FOREIGN KEY (`order_id`) REFERENCES `Order`(`order_id`) ON DELETE SET NULL ON UPDATE CASCADE;
